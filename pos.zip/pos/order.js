const API_BASE = "https://localhost:7141/api";   // change if needed
const orders = [];

document.addEventListener("DOMContentLoaded", () => {
    loadOrders();

    document.getElementById("searchInput")
        .addEventListener("input", applyFilters);

    document.getElementById("statusFilter")
        .addEventListener("change", applyFilters);
});

// 1. Load orders from API
async function loadOrders() {
    try {
        const token = localStorage.getItem("accessToken"); // if using JWT

        if(token === null) {
            console.warn("No access token found. Orders may not load if API requires authentication.");
            window.location.href = "login.html"; 
        }

        const response = await fetch(`${API_BASE}/Order`, {
            headers: {
                "Content-Type": "application/json",
                ...getAuthHeaders()
            }
        });

        if (!response.ok) {
            console.error("Failed to load orders:", await response.text());
            window.location.href = "login.html";
            return;
        }

        const data = await response.json();
        orders.splice(0, orders.length, ...data);
        renderOrders(orders);
    } catch (err) {
        console.error("Error loading orders:", err);
    }
}

// 2. Apply search + status filters
function applyFilters() {

    const search = document.getElementById("searchInput").value.trim().toLowerCase();
    const status = document.getElementById("statusFilter").value; 

    console.log("Applying filters - Search:", search, "Status:", status);

    const filtered = orders.filter(o => {
        const matchesStatus = (o.status === status || status === "All Status");
        const searchText =
            (o.orderNumber ?? "").toLowerCase();

        const matchesSearch = !search || searchText.includes(search);

        return matchesStatus && matchesSearch;
    });

    renderOrders(filtered);
    viewOrder(""); // clear details pane when filters change
}

// 3. Render table rows
function renderOrders(list) {
    const tbody = document.getElementById("ordersTableBody");
    tbody.innerHTML = "";

    if (!list.length) {
        const tr = document.createElement("tr");
        const td = document.createElement("td");
        td.colSpan = 6;
        td.className = "text-center text-muted";
        td.textContent = "No orders found.";
        tr.appendChild(td);
        tbody.appendChild(tr);
        return;
    }

    list.forEach(order => {
        const tr = document.createElement("tr");
        
        const orderTypeText = order.type;

        const totalText = `KWD ${Number(order.totalAmount).toFixed(3)}`;

        const statusBadge = createStatusBadge(order.status);

        tr.innerHTML = `
            <td>#${order.orderNumber}</td>
            <td>${orderTypeText}</td>
            <td>${totalText}</td>
            <td></td>
            <td>
                <button class="btn btn-sm btn-outline-primary" onclick="viewOrder(${order.id})">
                    View
                </button>
            </td>
        `;

        const statusCell = tr.children[3];
        statusCell.appendChild(statusBadge);

        tbody.appendChild(tr);
    });
}

function createStatusBadge(status) {
    const span = document.createElement("span");
    span.classList.add("badge");

    switch (status) {
        case "Completed":
            span.classList.add("bg-success");
            span.textContent = "Completed";
            break;
        case "Pending":
            span.classList.add("bg-warning", "text-dark");
            span.textContent = "Pending";
            break;
        case "Cancelled":
            span.classList.add("bg-danger");
            span.textContent = "Cancelled";
            break;
        default:
            span.classList.add("bg-secondary");
            span.textContent = status || "Unknown";
            break;
    }

    return span;
}

function viewOrder(orderid) {
    const order = orders.find(o => o.id === orderid);

    const pane = document.getElementById("orderDetails");
  pane.innerHTML = "";

  if (!order.orderItems || !order.orderItems.length) {
    const p = document.createElement("p");
    p.className = "text-muted";
    p.textContent = "No items in this order.";
    pane.appendChild(p);
    return;
  }

  const header = document.createElement("div");
  header.innerHTML = `
    <h6 class="mb-1">Order #${order.orderNumber}</h6>
    <div class="text-muted small">
      ${order.type} · 
      KWD ${Number(order.totalAmount).toFixed(3)}
    </div>
    <div class="mt-1">
      ${createStatusBadge(order.status).outerHTML}
    </div>
    <hr>
  `;
  pane.appendChild(header);

  const list = document.createElement("ul");
  list.className = "list-group list-group-flush";

  order.orderItems.forEach(item => {
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";

    const name = item.product?.name ?? `Product #${item.productId}`;
    const qtyPrice = `x${item.quantity} · KWD ${Number(item.unitPrice).toFixed(3)}`;

    li.innerHTML = `
      <div>
        <div>${name}</div>
        <div class="text-muted small">${qtyPrice}</div>
      </div>
      <div>
        KWD ${(item.unitPrice * item.quantity).toFixed(3)}
      </div>
    `;
    list.appendChild(li);
  });

  pane.appendChild(list);
}

function getAuthHeaders() {
    const token = localStorage.getItem("accessToken");
    return token
        ? { "Authorization": `Bearer ${token}` }
        : {};
}
