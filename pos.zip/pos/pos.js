const API_BASE = "https://localhost:7141/api";

// Simple in-memory cart
const cart = [];
let productTypes = [];
let selectedTypeId = null;
let orderType = 'Delivery';
let deliveryCharge = 0.300;
let subtotal = 0;

// Called when page loads
document.addEventListener("DOMContentLoaded", () => {
    loadCategories();
});

async function loadCategories() {
    try {
        const token = localStorage.getItem("accessToken"); // if using JWT

        if(token === null) {
            console.warn("No access token found. Orders may not load if API requires authentication.");
            window.location.href = "login.html"; 
        }

        const response = await fetch(`${API_BASE}/producttype`,{
        headers: {
        "Content-Type": "application/json",
        ...getAuthHeaders()
        }}); 

        if (!response.ok) throw new Error("Failed to load categories");

        productTypes = await response.json();
        renderCategories(productTypes);
    } catch (err) {
        console.error("Error loading categories:", err);
        window.location.href = "login.html";
    }
}

function renderCategories(productTypes) {
    const container = document.getElementById("categoriesContainer");
    container.innerHTML = ""; // clear
    container.classList.add("categories-list");
    let first = true;
    productTypes.forEach(cat => {

        const btn = document.createElement("button");
        btn.className = first ? "category-btn active" : "category-btn";        
        btn.id = cat.id;
        btn.textContent = cat.name;
        btn.addEventListener("click", () => loadProductsByCategory(cat.id));
        container.appendChild(btn);

        if(first)
        {
            loadProductsByCategory(cat.id);
        }
        first = false;
    });
}

async function loadProductsByCategory(categoryId) {
    try {
        const allButtons = document.querySelectorAll(".category-btn");
        allButtons.forEach(b => b.classList.remove("active"));
        
        const btn = document.getElementById(categoryId);        
        btn.classList.add("active");        

        const type = productTypes.find(t => t.id === categoryId);
        const items = type?.items ?? [];
        renderProducts(items);
    } catch (err) {
        console.error("Error loading products:", err);
    }
}

function renderProducts(products) {
    const container = document.getElementById("productsContainer");
    container.innerHTML = ""; // clear

    products.forEach(p => {
        const card = document.createElement("div");
        card.className = "product";

        card.innerHTML = `
            <strong>${p.name}</strong>
            <div>KWD ${p.price}</div>
        `;

        const btn = document.createElement("button");
        btn.textContent = "Add";
        btn.className = "btn btn-sm btn-primary mt-2";
        btn.addEventListener("click", () => addToCart(p));

        card.appendChild(btn);
        container.appendChild(card);
    });
}

// 3. Cart handling
function addToCart(product) {
    cart.push(product);
    renderCart();
}

function renderCart() {
    const ul = document.getElementById("cartItems");
    ul.innerHTML = "";
    subtotal = 0;
    cart.forEach(item => {
        subtotal += (item.price * (item.quantity ?? 1));

        const li = document.createElement("li");
        li.className = "cart-row border-bottom pb-2";

        // Left: name + quantity controls
        const left = document.createElement("div");
        left.className = "cart-left";

        const nameSpan = document.createElement("span");
        nameSpan.className = "cart-name";
        nameSpan.textContent = item.name;

        const qtyWrapper = document.createElement("div");
        qtyWrapper.className = "cart-qty";

        const minusBtn = document.createElement("button");
        minusBtn.textContent = "−";
        minusBtn.onclick = () => updateQty(item, -1);

        const qtySpan = document.createElement("span");
        qtySpan.textContent = item.quantity ?? 1;

        const plusBtn = document.createElement("button");
        plusBtn.textContent = "+";
        plusBtn.onclick = () => updateQty(item, +1);

        qtyWrapper.append(minusBtn, qtySpan, plusBtn);
        left.appendChild(nameSpan);
        left.appendChild(document.createElement("br"));
        left.appendChild(qtyWrapper);

        // Right: price
        const right = document.createElement("span");
        right.className = "cart-price";
        right.textContent = `KWD ${item.price}`;

        li.append(left, right);
        ul.appendChild(li);
    });

    document.getElementById('subTotal').innerText = subtotal.toFixed(3);
      document.getElementById('deliveryCharge').innerText = deliveryCharge.toFixed(3);
      document.getElementById('totalAmount').innerText =
        (subtotal + deliveryCharge).toFixed(3);
}

function updateQty(item, delta) {
    if(item.quantity == 1 && delta === -1) {
        const index = cart.indexOf(item);
        cart.splice(index, 1);
        renderCart();
    }
    else
    {
        item.quantity = Math.max(1, (item.quantity ?? 1) + delta);
        renderCart();
    }
}

function getAuthHeaders() {
    const token = localStorage.getItem("accessToken");
    return token
        ? { "Authorization": `Bearer ${token}` }
        : {};
}

function handleOrderTypeChange(select) {
    const value = select.value; 

    if (value === "Delivery") {
      deliveryCharge = 0.300;
      orderType = "Delivery";
    } else if (value === "DineIn") {
      deliveryCharge = 0;
        orderType = "DineIn";
    } else if (value === "TakeAway") {
        deliveryCharge = 0;
        orderType = "TakeAway";
    }
    calculateTotal();
  }

  function calculateTotal() {
      document.getElementById('deliveryCharge').innerText = deliveryCharge.toFixed(3);
      document.getElementById('totalAmount').innerText = (subtotal + deliveryCharge).toFixed(3);
  }

async function placeOrder() {
    if (cart.length === 0) {
        alert("Cart is empty!");
        return;
    }

    // const select = document.getElementById("orderTypeSelect");    

    const orderItems = cart.map(item => ({
        productId: item.id,          // ensure this matches your Product.Id
        quantity: item.quantity ?? 1,
        unitPrice: item.price
    }));

    const totalText = document.getElementById('totalAmount').innerText;

            const total = parseFloat(totalText);

     const order = {
        ordertype: orderType,
        totalAmount: total,
        status: "Pending",
        orderItems: orderItems
    };

    try { // if you use JWT

        const response = await fetch(`${API_BASE}/Order`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                ...getAuthHeaders()
            },
            body: JSON.stringify(order)
        });

        if (!response.ok) {
            const text = await response.text();
            console.error("Order save error:", text);
            alert("Failed to place order.");
            return;
        }

        const savedOrder = await response.json();
        console.log("Order saved:", savedOrder);
        alert(`Order placed. Number: ${savedOrder.orderNumber}`);

        // Clear cart & re-render
        cart.length = 0;
        renderCart();
        window.location.href = "orders.html";
    } catch (err) {
        console.error("Error placing order:", err);
        alert("Error while placing order.");
    }
}
